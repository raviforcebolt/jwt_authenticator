# jwt_authenticator
python code to publish on the pypi for jwt authenitcation with db integration
